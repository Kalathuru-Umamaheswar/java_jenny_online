package com.jennyslectures;

public class Professor extends User{
    public Professor(String userId,String name){
        super(userId,name);
    }


}
